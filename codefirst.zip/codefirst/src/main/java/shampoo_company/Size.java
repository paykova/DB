package shampoo_company;

public enum Size {
    BIG, SMALL, MEDIUM, LARGE
}
