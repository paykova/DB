create trigger tr_into_problems
  before INSERT
  on problems
  for each row
  BEGIN 
		IF(NEW.name NOT LIKE '% %')
        THEN SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'The given name is invalid!';
        
        ELSEIF(NEW.points <= 0)
        THEN SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'The problem\'s points cannot be less or equal to 0!';
        
        IF(NEW.tests <= 0)
        THEN SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'The problem\'s tests cannot be less or equal to 0!';
        END IF;
		INSERT INTO problems (id, name, points, tests, contest_id) 
        VALUES (NEW.id, NEW.name, NEW.points, NEW.contest_id);
        END IF;
    END;

