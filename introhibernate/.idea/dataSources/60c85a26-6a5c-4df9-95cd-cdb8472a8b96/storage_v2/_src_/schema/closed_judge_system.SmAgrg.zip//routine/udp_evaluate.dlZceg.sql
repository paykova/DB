create procedure udp_evaluate(IN id int)
  BEGIN
	IF(id NOT IN(SELECT s.id FROM submissions s))
    THEN SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Submission does not exist!';
    END IF;
    INSERT INTO evaluated_submissions
    SELECT s.id, p.name, u.username, (p.points / p.tests * s.passed_tests) AS result
    FROM users u
	JOIN submissions s ON u.id = s.user_id 
	JOIN problems p ON s.problem_id = p.id
    WHERE s.id = id; 
END;

