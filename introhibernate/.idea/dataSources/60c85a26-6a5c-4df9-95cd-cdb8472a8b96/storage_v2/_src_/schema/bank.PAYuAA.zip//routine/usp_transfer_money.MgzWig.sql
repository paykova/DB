create procedure usp_transfer_money(IN from_account_id int, IN to_account_id int, IN amount decimal(19, 4))
  BEGIN
	START TRANSACTION;
    
    IF
		((SELECT COUNT(a.id) FROM accounts AS a WHERE a.id = from_account_id) <> 1 OR 
		(SELECT COUNT(a.id) FROM accounts AS a WHERE a.id = to_account_id) <> 1 OR
        amount <= 0 OR
        (SELECT a.balance FROM accounts AS a WHERE a.id = from_account_id) < amount )
	THEN 
	ROLLBACK; 
	ELSE
        UPDATE accounts AS a SET a.balance = a.balance - amount WHERE a.id = from_account_id;
        UPDATE accounts AS a SET a.balance = a.balance + amount WHERE a.id = to_account_id;
	END IF;
END;

