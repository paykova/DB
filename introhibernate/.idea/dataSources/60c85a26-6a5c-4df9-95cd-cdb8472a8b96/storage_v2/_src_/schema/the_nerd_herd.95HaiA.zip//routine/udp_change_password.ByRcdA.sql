create procedure udp_change_password(IN email varchar(255), IN password varchar(255))
  BEGIN
		IF(SELECT COUNT(email) FROM credentials) = 0 
        THEN SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'The amail does\'t exist!';
        END IF;
		UPDATE credentials SET password = password WHERE email = email;
	END;

