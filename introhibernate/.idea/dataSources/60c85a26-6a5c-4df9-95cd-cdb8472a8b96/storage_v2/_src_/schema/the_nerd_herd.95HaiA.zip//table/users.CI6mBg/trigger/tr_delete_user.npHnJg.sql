create trigger tr_delete_user
  after DELETE
  on users
  for each row
  BEGIN
	INSERT INTO deleted_users 
    VALUES(OLD.id, OLD.nickname, OLD.gender, OLD.age, OLD.location_id, OLD.credential_id);
    DELETE FROM deleted_users WHERE id = OLD.id; 
END;

