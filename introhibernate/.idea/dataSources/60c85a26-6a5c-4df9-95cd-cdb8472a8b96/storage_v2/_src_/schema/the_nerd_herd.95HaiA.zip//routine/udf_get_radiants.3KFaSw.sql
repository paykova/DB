create function udf_get_radiants(degrees float)
  returns float
  BEGIN
		DECLARE result FLOAT;
        SET result := (SELECT degrees * PI() / 180);
        RETURN result; 
    END;

