create procedure udp_send_message(IN user_id int, IN chat_id int, IN message varchar(200))
  BEGIN
    IF (user_id NOT IN (SELECT m.user_id FROM messages AS m))
		THEN SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'There is no chat with that user!';
        END IF;
		SELECT message AS content, '2016-12-15' AS sent_on, chat_id, user_id; 
    END;

