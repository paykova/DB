create procedure udp_submit_review(IN customer_id  int, IN review_content varchar(255), IN review_grade int,
                                   IN airline_name varchar(255))
  BEGIN
	IF(ailine_name NOT IN(SELECT a.airline_name FROM airlines AS a))
    THEN SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Airline does not exist!';
    END IF; 
	INSERT INTO customer_reviews (revied_content, review_grade, airline_id, customer_id) 
    SELECT review_content, review_grade, a.airline_name, customer_id FROM airlines AS a; 
    
END;

