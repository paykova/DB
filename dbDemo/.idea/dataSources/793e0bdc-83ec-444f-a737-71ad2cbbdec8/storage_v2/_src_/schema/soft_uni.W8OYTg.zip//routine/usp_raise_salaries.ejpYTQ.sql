create procedure usp_raise_salaries(IN department_name varchar(50))
  BEGIN
	UPDATE employees AS e JOIN departments AS d ON e.department_id = d.department_id
	SET salary = salary + 0.05 * salary 
	WHERE d.name = department_name; 
END;

