create function ufn_get_salary_level(salary_to_compare decimal(19, 2))
  returns varchar(50)
  BEGIN
	DECLARE salary_level_result VARCHAR(50);
	SET salary_level_result := (
	CASE 
		WHEN salary_to_compare < 30000 THEN  'Low'
		WHEN salary_to_compare >= 30000 AND salary_to_compare <= 50000 THEN  'Average'
		WHEN salary_to_compare > 50000 THEN 'High'
	END);
	RETURN salary_level_result;
END;

