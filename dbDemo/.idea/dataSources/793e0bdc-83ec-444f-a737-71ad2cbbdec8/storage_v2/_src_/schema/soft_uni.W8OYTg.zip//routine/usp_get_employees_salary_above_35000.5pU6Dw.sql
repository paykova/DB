create procedure usp_get_employees_salary_above_35000()
  BEGIN 
	SELECT e.first_name, e.last_name
	FROM employees AS e
	WHERE salary > 35000
	ORDER BY first_name, last_name, e.employee_id; 
END;

