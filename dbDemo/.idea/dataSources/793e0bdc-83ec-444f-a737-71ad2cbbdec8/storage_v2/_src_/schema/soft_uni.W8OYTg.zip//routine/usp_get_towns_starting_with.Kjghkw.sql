create procedure usp_get_towns_starting_with(IN letter char)
  BEGIN
	SELECT t.name FROM towns t WHERE LOWER(SUBSTRING(t.name, 1, CHAR_LENGTH(letter))) = LOWER(letter) ORDER BY t.name; 
END;

