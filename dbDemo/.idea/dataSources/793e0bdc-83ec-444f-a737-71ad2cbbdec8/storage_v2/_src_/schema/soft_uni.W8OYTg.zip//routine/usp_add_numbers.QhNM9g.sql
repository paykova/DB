create procedure usp_add_numbers(IN first_number int, IN second_number int, OUT result int)
  BEGIN
	SET result = first_number + second_number;
END;

