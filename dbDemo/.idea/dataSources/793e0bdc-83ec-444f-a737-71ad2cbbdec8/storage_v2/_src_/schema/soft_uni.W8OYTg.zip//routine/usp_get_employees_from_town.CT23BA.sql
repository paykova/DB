create procedure usp_get_employees_from_town(IN town_name varchar(50))
  BEGIN 
	SELECT e.first_name, e.last_name
	FROM towns t 
	JOIN addresses a ON a.town_id = t.town_id
	JOIN employees e ON e.address_id = a.address_id
	WHERE t.name LIKE town_name
	ORDER BY e.first_name, e.last_name, employee_id; 
END;

