create procedure usp_select_employees_by_seniority(IN min_years_at_work int)
  BEGIN
	SELECT first_name, last_name, hire_date,
    ROUND(DATEDIFF(NOW(), DATE(e.hire_date))/365.25,0) AS years
    FROM employees AS e
    WHERE ROUND(DATEDIFF(NOW(), DATE(e.hire_date))/365.25,0) > min_years_at_work
    ORDER BY e.hire_date; 
END;

