create procedure usp_get_employees_salary_above(IN number decimal)
  BEGIN 
	SELECT e.first_name, e.last_name
	FROM employees AS e
	WHERE salary >= number
	ORDER BY first_name, last_name, e.employee_id; 
END;

