create procedure usp_raise_salary_by_id(IN id int)
  BEGIN
	UPDATE employees SET salary = salary + salary * 0.05 WHERE employee_id = id; 
END;

