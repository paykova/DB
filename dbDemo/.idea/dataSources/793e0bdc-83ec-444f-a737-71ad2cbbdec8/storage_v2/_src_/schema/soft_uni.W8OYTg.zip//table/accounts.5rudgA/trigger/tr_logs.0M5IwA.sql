create trigger tr_logs
  after UPDATE
  on accounts
  for each row
  BEGIN
	INSERT INTO logs (account_id, old_sum, new_sum)
    VALUES (OLD.id, OLD.balance, NEW.balance);
END;

