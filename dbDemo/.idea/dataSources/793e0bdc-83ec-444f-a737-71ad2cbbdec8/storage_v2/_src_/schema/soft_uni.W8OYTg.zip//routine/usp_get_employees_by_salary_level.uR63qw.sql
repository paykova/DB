create procedure usp_get_employees_by_salary_level(IN some_level varchar(50))
  BEGIN
	SELECT e.first_name, e.last_name FROM employees AS e
    WHERE ufn_get_salary_level (salary_to_compare) = some_level
    ORDER BY e.first_name DESC, e.last_name DESC;
END;

