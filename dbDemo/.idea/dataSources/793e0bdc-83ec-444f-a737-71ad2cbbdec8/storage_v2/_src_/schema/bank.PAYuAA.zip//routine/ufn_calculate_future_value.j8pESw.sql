create function ufn_calculate_future_value(total decimal(20, 4), rate decimal(20, 4), years int)
  returns decimal(20, 4)
  BEGIN 
	DECLARE result DECIMAL(20, 4);
	SET result = total * POW((1 + rate), years);
	return result;
END;

