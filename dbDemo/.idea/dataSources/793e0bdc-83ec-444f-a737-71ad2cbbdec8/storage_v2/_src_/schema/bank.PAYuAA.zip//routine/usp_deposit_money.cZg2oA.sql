create procedure usp_deposit_money(IN account_id int, IN money_amount decimal(20, 4))
  BEGIN
START TRANSACTION;
	CASE WHEN money_amount < 0
		THEN ROLLBACK;
	ELSE 
		UPDATE account AS a
	SET a.balance = a.balance + money_amount
    WHERE a.id = account_id;
    END CASE;
COMMIT;
END;

